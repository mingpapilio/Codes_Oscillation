# -*- coding: utf-8 -*-
## Loading packages
import numpy as np
from matplotlib import pyplot as plt
from math import *
import seaborn as sns
from scipy.integrate import odeint
import numba
from numba import jit
import time
import random
## For deprecation warnings
from numba import NumbaDeprecationWarning, NumbaPendingDeprecationWarning
import warnings
import sys
warnings.simplefilter('ignore', category=NumbaDeprecationWarning)
warnings.simplefilter('ignore', category=NumbaPendingDeprecationWarning)

# Replication (The ODE function)
@jit #faster than Cython 
def replication(v0, t, Cn, a, b):
    # v0 is the list of densities; r= 1 (omitted); Cn= 300; 
    dv = np.empty_like(v0)
    Capacity = (1-(v0[0]+v0[1])/Cn)
    Grate= [2.,2.]
    dv[0]= Grate[0]*v0[0]*Capacity
    if(np.sum(v0)> 0):
        dv[1]= Grate[1]*v0[1]*4.0*(1-a+a/(1+np.exp(-3*(v0[0]-1.5))))*(1-b+b/(1+np.exp(-10*(v0[0]/(np.sum(v0))-0.5))))*Capacity
    else:
        dv[1]= 0.
    return dv

#Initial concentrations
def initial(M, Coop_i, Cheat_i):
    comps = np.vstack([np.random.poisson(popn/float(M),M) for popn in [Coop_i, Cheat_i]]) 
    return comps

#Dilution (Diluted D times and convert densities to integer)
def dilution(D,M,comps):
    np.random.shuffle(comps.T) #Randomization
    comps= comps[:,:round(M/D)] #Dilution
    newcomps = np.vstack([np.zeros(M-round(M/D)) for i in range(2)]) #New compartments
    comps = np.hstack([comps, newcomps]) #Combine
    return comps

#Repartition (Fusion-division of two randomly picked compartments)
def repartition(Fnumber, comps):
    X = list(range(M))
    ids = [random.sample(X, 2) for i in range(Fnumber)] #randomly choose two compartments for M*F times
    for i in ids:
        p,q = i[0],i[1]
        if np.sum(comps[:,p]+comps[:,q])>0: #Other than two vacant compartments
            fuse = (comps[:,p] + comps[:,q]).astype(np.int32) #Fusion of two compartments
            comps[0,p], comps[1,p] = \
                np.random.binomial(fuse[0],0.5),np.random.binomial(fuse[1],0.5) ## Division; all 0.5 probability!? Everything is treated as interger in this simulation
            comps[:,q] = fuse - comps[:,p]
    return comps
# Input processing
input= sys.argv[1]
input= input.replace(" ","")
input= input.replace("a=","")
a= float(input)

input= sys.argv[2]
input= input.replace(" ","")
input= input.replace("b=","")
b= float(input)

# Serial transfer
Round= 200
M= 4000
Cn= 100 #C in the paper
D= 5
Fnumber=int(M*1.3) #M*F in the paper; the number of repeating mixing processes
IDs = np.array(['Coop','Cheat']) #each corresponds to cooperators and cheats
#
t_reaction= 4.
N_dots= 10
t = np.linspace(0, t_reaction, N_dots) #
#
for X in range(1):
    [Coop_i,Cheat_i]=[M,M]
    Coop_s, Cheat_s= [Coop_i], [Cheat_i]
    concs= [[Coop_i/M, Cheat_i/M]]
    fit_avgs= [[0., 0.]]
    fit_sds= [[0., 0.]]
    rfit_avgs= [[0., 0.]]
    rfit_sds= [[0., 0.]]
    #transfer
    comps= initial(M,Coop_i,Cheat_i)
    comp_fits= np.empty_like(comps)
    comp_rfit= np.ndarray((2,len(comps[0])))
    #print(comps[:,:round(M/D)])
    R_true = 0
    for R in range(Round):
        R_true+=1
        if np.sum(comps)>0: #only if a replicator is remaining
            if R > 0:
                comps = dilution(D,M,comps) #dilution
                comps = repartition(Fnumber, comps) #repartition
                active_comp_IDs = np.where(np.sum(comps,axis=0)>0)[0] #IDs of compartments containing molecules
                comps = np.hstack([comps[:,active_comp_IDs]]) #obtain compartments containing molecules
            #replication
            for k in range(len(comps[0])):
                RNAs = np.hstack([comps[j][k] for j in range(2)])
                v =  odeint(replication, RNAs, t, args=(Cn,a,b))
                ## Get the old CheaFreq
                if (comps[0][k]+comps[1][k])>0:
                    CheaFreq= comps[1][k]/(comps[0][k]+comps[1][k])
                else:
                    CheaFreq= float("nan")
                ##
                for l in range(2):
                    comps[l][k]=round(v[-1][l])
                    #
                    if v[0][l]!=0:
                        comp_fits[l][k]= (v[-1][l]-v[0][l])/t_reaction/(v[0][l])
                    else:
                        comp_fits[l][k]= 0
                ##
                if ((1-CheaFreq)*comps[0][k]+CheaFreq*comps[1][k])>0 and CheaFreq!=float("nan"):
                    comp_rfit[0][k]= comp_fits[0][k]*(1-CheaFreq)/((1-CheaFreq)*comps[0][k]+CheaFreq*comps[1][k])
                    comp_rfit[1][k]= comp_fits[1][k]*CheaFreq/((1-CheaFreq)*comps[0][k]+CheaFreq*comps[1][k])
                else:
                    comp_rfit[0][k]= float("nan")
                    comp_rfit[1][k]= float("nan")
                #### Note: frequency should be old frequency, not the updated one. ####
            #return vacant compartments
            new = M-len(comps[0])
            comps = np.hstack([comps,np.zeros(new*2).reshape(2,new)])
        # Appending new rows
        concs= np.append(concs, [np.sum(comps, axis= 1)/M], axis= 0)
        rfit_avgs= np.append(rfit_avgs, [[np.nanmean(comp_rfit[0]), np.nanmean(comp_rfit[1])]], axis=0)
        rfit_sds= np.append(rfit_sds, [[np.nanstd(comp_rfit[0]), np.nanstd(comp_rfit[1])]], axis= 0)
##
popn_file= open("Popn_7.txt", "w")
popn_file.write("Round\tCoop\tChea\tCheaFreq\tCoopRFit_avg\tCoopRFit_sd\tCheaRFit_avg\tCheaRFit_sd\n")
for i in range(concs.shape[0]):
    if (concs[i,0]+concs[i,1])> 0:
        CheaFreq= concs[i,1]/(concs[i,0]+concs[i,1])
    else:
        CheaFreq= float("nan")
    popn_file.write("%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n" % (i, concs[i,0], concs[i,1], CheaFreq, rfit_avgs[i,0], rfit_sds[i,0], rfit_avgs[i,1], rfit_sds[i,1]))
popn_file.close()
